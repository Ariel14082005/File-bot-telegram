const TelegramBot = require("node-telegram-bot-api");
const makeWASocket = require("@whiskeysockets/baileys").default;
const { useMultiFileAuthState } = require("@whiskeysockets/baileys");
const path = require("path");

const config = require("../config/config");
const handler = require("./handler");

const BASE = path.join(__dirname, "..");
const SESSION_DIR = path.join(BASE, "storage/session");
const SENT_DIR = path.join(BASE, "storage/sent");

async function start() {
    try {
        // ===== Inisialisasi auth state =====
        const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

        // ===== Buat socket WA =====
        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: true
        });

        sock.ev.on("creds.update", saveCreds);

        sock.ev.on("connection.update", (update) => {
            const { connection, lastDisconnect } = update;
            if(connection === "close") {
                console.log("❌ WA Connection closed:", lastDisconnect?.error || "unknown");
            } else if(connection === "open"

            setInterval(() => {
                console.log("JUMLAH KONTAK:", Object.keys(store.contacts || {}).length);
            }, 5000);) {
                console.log("✅ WA Bot connected!");
            }
        });

        sock.ev.on("messages.upsert", (msg) => {
            console.log("📩 Pesan WA masuk:", msg.messages?.[0]?.message || msg);
        });

        // ===== Buat Telegram Bot =====
        const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });

        // ===== Panggil handler =====
        handler(bot, sock, SENT_DIR);

        console.log("🚀 Bot WA + Telegram siap!");

    } catch (err) {
        console.log("💥 Error bot:", err);
        process.exit(1); // keluar jika fatal error
    }
}

// Jalankan bot
start();

// ===== Error global =====
process.on("uncaughtException", (err) => {
    console.log("💥 Uncaught Error:", err);
});

process.on("unhandledRejection", (err) => {
    console.log("💥 Promise Error:", err);
});