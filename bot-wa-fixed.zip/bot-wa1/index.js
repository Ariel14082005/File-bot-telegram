const fs = require("fs");
const axios = require("axios");
const path = require("path");

// ===== CONFIG =====
const CONFIG = {
    VERSION_URL: ""
};

// ===== PATH =====
const BASE = __dirname;
const STORAGE = path.join(BASE, "storage");
const SESSION = path.join(STORAGE, "session");
const KEYS = path.join(SESSION, "keys");
const SENT = path.join(STORAGE, "sent");

const USERS_FILE = path.join(STORAGE, "user.json");
const LOG_FILE = path.join(STORAGE, "log.json");
const VERSION_FILE = path.join(BASE, "version.json");

// ===== INIT FOLDER & FILE =====
function initSystem() {
    console.log("⚙️ Inisialisasi sistem...");

    const dirs = [STORAGE, SESSION, KEYS, SENT];

    dirs.forEach(dir => {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
            console.log("📁 Buat folder:", dir);
        }
    });

    if (!fs.existsSync(USERS_FILE)) {
        fs.writeFileSync(USERS_FILE, "{}");
        console.log("📄 users.json dibuat");
    }

    if (!fs.existsSync(LOG_FILE)) {
        fs.writeFileSync(LOG_FILE, "[]");
        console.log("📄 log.json dibuat");
    }

    if (!fs.existsSync(path.join(SESSION, "creds.json"))) {
        fs.writeFileSync(path.join(SESSION, "creds.json"), "{}");
        console.log("📄 creds.json dibuat");
    }
}

// ===== VERSION =====
function getVersion() {
    if (!fs.existsSync(VERSION_FILE)) {
        fs.writeFileSync(VERSION_FILE, JSON.stringify({ version: "1.0.0.0" }, null, 2));
    }
    return JSON.parse(fs.readFileSync(VERSION_FILE));
}

// ===== CEK UPDATE =====
async function checkUpdate() {
    try {
        const local = getVersion();
        const res = await axios.get(CONFIG.VERSION_URL);
        const remote = res.data;

        if (local.version !== remote.version) {
            console.log(`🔄 Update tersedia: ${local.version} → ${remote.version}`);
        } else {
            console.log("✅ Versi terbaru:", local.version);
        }

    } catch (err) {
        console.log("❌ Gagal cek update:", err.message);
    }
}

// ===== START BOT =====
function startBot() {
    try {
        console.log("🚀 Menjalankan bot...");
        require("./app/bot");
    } catch (err) {
        console.log("💥 Error start bot:", err.message);
    }
}

// ===== ERROR HANDLER =====
process.on("uncaughtException", (err) => {
    console.log("💥 Uncaught Error:", err);
});

process.on("unhandledRejection", (err) => {
    console.log("💥 Promise Error:", err);
});


// ===== INIT =====
(async () => {
    console.log("=================================");
    console.log("🚀 WA BOT STARTING...");
    console.log("=================================");

    initSystem();

    const v = getVersion();
    console.log("📦 Versi:", v.version);

    await checkUpdate();

    startBot();

    // cek update tiap 10 menit
    setInterval(checkUpdate, 3600000);
})();