const fs = require("fs");
const { exec } = require("child_process");
const path = require("path");

const LOG_FILE = path.join(__dirname, "storage/log.json");
if (!fs.existsSync(LOG_FILE)) {
    console.log("❌ storage/log.json tidak ditemukan");
    process.exit(0);
}

const BACKUP_DIR = path.join(__dirname, "backup/log_backup");
if (!fs.existsSync(BACKUP_DIR)) fs.mkdirSync(BACKUP_DIR, { recursive: true });

fs.copyFileSync(LOG_FILE, path.join(BACKUP_DIR, "log.json"));

exec(`
  cd ${BACKUP_DIR} &&
  git init &&
  git add log.json &&
  git commit -m "backup log ${new Date().toISOString()}" &&
  git remote add origin https://github.com/Ariel14082005/wa-bot-logs.git 2>/dev/null || true &&
  git push -u origin master --force
`, (err) => {
    if (err) console.log("❌ Backup log gagal:", err.message);
    else console.log("✅ Backup log berhasil ke GitHub");
});