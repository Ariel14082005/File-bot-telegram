const path = require("path");
const logger = require("./utils/logger");        // log otomatis
const { delay } = require("./utils/optimize");   // delay & batchProcess
const func = require("./app/function.js");         // helper: randomDelay, formatTime
const handler = require("./app/handler");        // semua perintah bot

const fs = require("fs");
const SESSION_DIR = path.join(__dirname, "storage/session");

// CONFIG
const config = require("./config/config.js");

// ==============================
// INISIALISASI FOLDER & FILE
// ==============================
function initSystem() {
    logger.info("⚙️ Inisialisasi sistem...");
    const dirs = [
        path.join(__dirname, "storage"),
        path.join(__dirname, "storage/session"),
        path.join(__dirname, "storage/sent")
    ];
    dirs.forEach(dir => { if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); });

    const files = [
        { path: path.join(__dirname, "storage/log.json"), content: "[]" },
        { path: path.join(__dirname, "storage/user.json"), content: "{}" },
        { path: path.join(__dirname, "storage/session/creds.json"), content: "{}" }
    ];
    files.forEach(f => { if (!fs.existsSync(f.path)) fs.writeFileSync(f.path, f.content); });
}

// ==============================
// START BOT
// ==============================
async function startBot() {
    logger.info("🚀 Menjalankan bot...");
    const makeWASocket = require("@whiskeysockets/baileys").default;
    const { useMultiFileAuthState } = require("@whiskeysockets/baileys");
    const TelegramBot = require("node-telegram-bot-api");

    // multi-file auth untuk WA
    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    });
    sock.ev.on("creds.update", saveCreds);

    // telegram bot
    const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });

    // hubungkan handler
    handler(bot, sock, config);
}

// ==============================
// ERROR HANDLER GLOBAL
// ==============================
process.on("uncaughtException", err => logger.error("Uncaught Error: " + err));
process.on("unhandledRejection", err => logger.error("Promise Error: " + err));

// ==============================
// INIT & START
// ==============================
(async () => {
    console.clear();
    logger.info("=================================");
    logger.info("🚀 WA BOT STARTING...");
    logger.info("=================================");

    initSystem();

    await startBot();
})();