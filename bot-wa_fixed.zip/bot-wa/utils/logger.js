const fs = require("fs");
const path = require("path");

const LOG_FILE = path.join(__dirname, "../storage/log.json");
if (!fs.existsSync(LOG_FILE)) fs.writeFileSync(LOG_FILE, "[]");

function saveLog(type, message) {
    const logs = JSON.parse(fs.readFileSync(LOG_FILE));
    logs.push({
        time: new Date().toISOString(),
        type,
        message
    });
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
}

function info(msg) { console.log("ℹ️", msg); saveLog("info", msg); }
function error(msg) { console.log("❌", msg); saveLog("error", msg); }
function broadcast(msg) { console.log("📤", msg); saveLog("broadcast", msg); }

module.exports = { info, error, broadcast };