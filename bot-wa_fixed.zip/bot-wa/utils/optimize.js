const delay = (ms) => new Promise(res => setTimeout(res, ms));

async function batchProcess(items, batchSize, callback, rest = 30000) {
    for (let i = 0; i < items.length; i += batchSize) {
        const batch = items.slice(i, i + batchSize);
        await Promise.all(batch.map(callback));
        console.log(`😴 Istirahat ${rest / 1000} detik untuk optimasi`);
        await delay(rest);
    }
}

module.exports = { delay, batchProcess };