const fs = require("fs");
const path = require("path");

// ===== FILE =====
const USERS_FILE = path.join(__dirname, "../storage/users.json");

// ===== LOAD USERS =====
let users = {};

function loadUsers() {
    try {
        users = JSON.parse(fs.readFileSync(USERS_FILE));
    } catch {
        users = {};
    }
}

function saveUsers() {
    try {
        fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
    } catch (err) {
        console.error("❌ Gagal menyimpan users:", err.message);
    }
}

// ===== INIT USER =====
function initUser(chatId) {
    if (!users[chatId]) {
        users[chatId] = {
            isRunning: false,
            waiting: false,
            message: "",
            sent: [],
            sentSet: new Set(),
            total: 0,
            sentCount: 0
        };
    }
}

// ===== DELAY =====
const delay = (ms) => new Promise(res => setTimeout(res, ms));

function randomDelay(min = 5000, max = 20000) {
    return Math.floor(Math.random() * (max - min)) + min;
}

// ===== BROADCAST =====
async function runBroadcast(bot, sock, chatId, contacts, user) {
    for (let i = 0; i < contacts.length; i++) {
        const id = contacts[i];

        // anti double kirim
        if (user.sentSet.has(id)) continue;

        try {
            await sock.presenceSubscribe(id);
            await sock.sendPresenceUpdate("composing", id);

            await delay(3000);

            await sock.sendMessage(id, { text: user.message });

            await sock.sendPresenceUpdate("paused", id);

            user.sent.push(id);
            user.sentSet.add(id);
            user.sentCount++;

            console.log("✅ Terkirim:", id);
        } catch (err) {
            console.log("❌ Gagal kirim ke", id, err.message);
        }

        // Update progress tiap 40 kontak
        if (user.sentCount % 40 === 0 || i === contacts.length - 1) {
            bot.sendMessage(chatId, `📊 Progress: ${user.sentCount}/${user.total}`);
            console.log("💤 Istirahat sebentar...");
            await delay(60000); // istirahat 1 menit tiap batch 40
        }

        await delay(randomDelay());
    }
}

// ===== MAIN HANDLER =====
module.exports = async (bot, sock, msg, config) => {
    if (!msg || !msg.chat) return;

    const chatId = msg.chat.id;
    const text = msg.text?.trim();
    loadUsers();
    initUser(chatId);
    const user = users[chatId];

    // ===== SECURITY =====
    if (!config.OWNER.includes(chatId)) {
        return bot.sendMessage(chatId, "❌ Akses ditolak");
    }

    // ===== LOCK =====
    if (user.isRunning && text !== "/status") {
        return bot.sendMessage(chatId, "⚠️ Bot sedang berjalan...");
    }

    // ===== COMMAND =====
    switch (text) {
        case "/start":
            return bot.sendMessage(chatId, "✅ Bot aktif");
        case "/broadcast":
            user.waiting = true;
            saveUsers();
            return bot.sendMessage(chatId, "📩 Kirim pesan broadcast sekarang");
        case "/cek": {
            const contacts = Object.keys(sock.store?.contacts || {});
            return bot.sendMessage(chatId, `📊 Total kontak: ${contacts.length}`);
        }
        case "/run": {
            if (!user.message) return bot.sendMessage(chatId, "❌ Pesan belum ada");

            const contacts = Object.keys(sock.store?.contacts || {});
            user.isRunning = true;
            user.sent = [];
            user.sentSet = new Set();
            user.sentCount = 0;
            user.total = contacts.length;

            saveUsers();
            bot.sendMessage(chatId, `🚀 Mulai kirim ke ${contacts.length} kontak`);
            await runBroadcast(bot, sock, chatId, contacts, user);
            user.isRunning = false;
            saveUsers();

            return bot.sendMessage(chatId, "🎉 Broadcast selesai");
        }
        case "/status":
            return bot.sendMessage(chatId, `📊 Progress: ${user.sentCount}/${user.total}`);
        default:
            if (user.waiting && text) {
                if (!text) return bot.sendMessage(chatId, "❌ Pesan kosong");
                user.message = text;
                user.waiting = false;
                saveUsers();
                return bot.sendMessage(chatId, "✅ Pesan broadcast disimpan");
            }
            break;
    }
};