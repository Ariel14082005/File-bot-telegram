// ===== FORMAT TIME DENGAN DETIK =====
function formatTime(ms) {
    let totalSeconds = Math.floor(ms / 1000);
    let hours = Math.floor(totalSeconds / 3600);
    let minutes = Math.floor((totalSeconds % 3600) / 60);
    let seconds = totalSeconds % 60;

    let result = [];
    if (hours) result.push(`${hours} jam`);
    if (minutes) result.push(`${minutes} menit`);
    if (seconds || (!hours && !minutes)) result.push(`${seconds} detik`);

    return result.join(' ');
}

// ===== CONTOH PENGGUNAAN =====
console.log(formatTime(3661000)); // "1 jam 1 menit 1 detik"
console.log(formatTime(60000));   // "1 menit"
console.log(formatTime(5000));    // "5 detik"