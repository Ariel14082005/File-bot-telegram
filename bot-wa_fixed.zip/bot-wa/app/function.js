const fs = require("fs");
const path = require("path");
const logger = require("../utils/logger");
const func = require("./function");

const USERS_FILE = path.join(__dirname, "../storage/user.json");

let users = {};

// ================= SAFE JSON =================
function loadUsers() {
    try {
        users = JSON.parse(fs.readFileSync(USERS_FILE, "utf-8"));
    } catch {
        users = {};
    }
}

function saveUsers() {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

// ================= INIT USER =================
function initUser(chatId) {
    if (!users[chatId]) {
        users[chatId] = {
            isRunning: false,
            waiting: false,
            message: "",
            sent: [],
            total: 0,
            sentCount: 0
        };
    }
}

// ================= BROADCAST =================
async function runBroadcast(bot, sock, store, chatId, contacts, user) {

    let failCount = 0;
    const DAILY_LIMIT = 150;

    for (let i = 0; i < contacts.length; i++) {

        const id = contacts[i];

        if (!user.isRunning) break;

        if (user.sent.includes(id)) continue;

        if (user.sentCount >= DAILY_LIMIT) {
            user.isRunning = false;
            bot.sendMessage(chatId, "⚠️ Limit harian tercapai");
            break;
        }

        try {
            const name = store.contacts[id]?.name || "kak";
            const msg = `Halo ${name}, ${func.randomMessage(user.message)}`;

            // typing simulation
            await sock.sendPresenceUpdate("composing", id);
            await new Promise(r => setTimeout(r, func.humanDelay()));

            await sock.sendMessage(id, { text: msg });

            user.sent.push(id);
            user.sentCount++;

            logger.broadcast(`✅ ${id}`);

        } catch (err) {
            failCount++;
            logger.error(`❌ ${id} - ${err.message}`);

            if (failCount >= 10) {
                user.isRunning = false;
                bot.sendMessage(chatId, "❌ Terlalu banyak gagal, dihentikan demi keamanan");
                break;
            }
        }

        // delay antar pesan
        await new Promise(r => setTimeout(r, func.humanDelay()));

        // progress update
        if (user.sentCount % 20 === 0) {
            bot.sendMessage(chatId, `📊 Progress: ${user.sentCount}/${user.total}`);
        }

        // REST RANDOM SETIAP BATCH
        if (user.sentCount % (30 + func.random(0, 20)) === 0) {
            const rest = 300000 + Math.random() * 600000; // 5–15 menit
            logger.info(`😴 Istirahat ${func.formatTime(rest)}`);
            await new Promise(r => setTimeout(r, rest));
        }
    }
}

// ================= MAIN =================
module.exports = (bot, sock, store, config) => {

    bot.on("message", async (msg) => {

        if (!msg || !msg.chat) return;

        const chatId = msg.chat.id;
        const text = msg.text || "";

        loadUsers();
        initUser(chatId);
        const user = users[chatId];

        if (!config.OWNER.includes(chatId)) {
            return bot.sendMessage(chatId, "❌ Akses ditolak");
        }

        // ================= COMMAND =================

        if (text === "/start") {
            return bot.sendMessage(chatId, "✅ Bot aktif");
        }

        if (text === "/broadcast") {
            user.waiting = true;
            saveUsers();
            return bot.sendMessage(chatId, "📩 Kirim pesan broadcast");
        }

        if (text === "/cek") {
            const contacts = Object.keys(store.contacts || {})
                .filter(id => id.endsWith("@s.whatsapp.net"));

            return bot.sendMessage(chatId, `📊 Total kontak: ${contacts.length}`);
        }

        if (text === "/stop") {
            user.isRunning = false;
            saveUsers();
            return bot.sendMessage(chatId, "⛔ Broadcast dihentikan");
        }

        if (text === "/run") {
            if (!user.message) {
                return bot.sendMessage(chatId, "❌ Pesan belum ada");
            }

            const contacts = Object.keys(store.contacts || {})
                .filter(id => id.endsWith("@s.whatsapp.net"));

            if (contacts.length === 0) {
                return bot.sendMessage(chatId, "❌ Kontak kosong");
            }

            user.isRunning = true;
            user.sent = [];
            user.sentCount = 0;
            user.total = contacts.length;

            saveUsers();

            bot.sendMessage(chatId, `🚀 Mulai kirim ke ${contacts.length} kontak`);

            await runBroadcast(bot, sock, store, chatId, contacts, user);

            user.isRunning = false;
            saveUsers();

            return bot.sendMessage(chatId, "🎉 Broadcast selesai");
        }

        if (text === "/status") {
            return bot.sendMessage(chatId, `📊 Progress:\n${user.sentCount}/${user.total}`);
        }

        // SIMPAN PESAN
        if (user.waiting && text) {
            user.message = text;
            user.waiting = false;
            saveUsers();

            return bot.sendMessage(chatId, "✅ Pesan disimpan");
        }

    });

};