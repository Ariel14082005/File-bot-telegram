const TelegramBot = require("node-telegram-bot-api");
const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    makeInMemoryStore
} = require("@whiskeysockets/baileys");

const fs = require("fs");
const path = require("path");
const P = require("pino");
const QRCode = require("qrcode");

const config = require("../config/config");
const handler = require("./handler");

// ===== TELEGRAM =====
const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });

// ===== SESSION =====
const SESSION_DIR = path.join(__dirname, "../storage/session");

// pastikan folder ada
if (!fs.existsSync(SESSION_DIR)) {
    fs.mkdirSync(SESSION_DIR, { recursive: true });
}

// ===== STORE =====
const store = makeInMemoryStore({});

// load store aman
try {
    if (fs.existsSync("./storage/baileys_store.json")) {
        store.readFromFile("./storage/baileys_store.json");
    }
} catch (err) {
    console.log("⚠️ Store error:", err.message);
}

// autosave store
setInterval(() => {
    store.writeToFile("./storage/baileys_store.json");
}, 10000);

// ===== START WA =====
async function startWA() {
    console.log("1. START WA");

    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);
    console.log("2. SESSION OK");

    // 🔥 FIX VERSION (WAJIB DI STB)
    const version = [2, 2413, 1];

    const sock = makeWASocket({
        version,
        auth: state,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        printQRInTerminal: true,
        logger: P({ level: "silent" }),
        connectTimeoutMs: 60000,
        keepAliveIntervalMs: 10000
    });

    console.log("3. SOCKET OK");

    // bind store
    store.bind(sock.ev);
    sock.store = store;

    // simpan session
    sock.ev.on("creds.update", saveCreds);

    // ===== CONNECTION =====
    sock.ev.on("connection.update", async (update) => {
        console.log("UPDATE FULL:", JSON.stringify(update, null, 2)); // 🔥 DEBUG

        const { connection, lastDisconnect, qr } = update;

        // ===== QR =====
        if (qr) {
            console.log("🔥 QR TERDETEKSI");

            try {
                const buffer = await QRCode.toBuffer(qr);

                if (config.OWNER && config.OWNER.length > 0) {
                    console.log("📤 Kirim QR ke Telegram...");
                    for (let id of config.OWNER) {
                        await bot.sendPhoto(id, buffer, {
                            caption: "📲 Scan QR WhatsApp ini"
                        });
                    }
                } else {
                    console.log("⚠️ OWNER kosong, QR hanya tampil di terminal");
                }

            } catch (err) {
                console.log("❌ QR error:", err.message);
            }
        }

        // ===== CONNECTED =====
        if (connection === "open") {
            console.log("✅ WhatsApp tersambung!");
        }

        // ===== RECONNECT =====
        if (connection === "close") {
            const reason = lastDisconnect?.error?.output?.statusCode;

            console.log("❌ WA CLOSE:", reason);

            if (reason !== DisconnectReason.loggedOut) {
                console.log("🔄 Reconnect...");
                setTimeout(startWA, 5000);
            } else {
                console.log("⚠️ Logout, hapus session untuk login ulang");
            }
        }
    });

    // ===== TELEGRAM =====
    bot.removeAllListeners("message"); // 🔥 cegah dobel
    bot.on("message", (msg) => {
        handler(bot, sock, msg, config);
    });

    console.log("🤖 Telegram bot aktif...");
}

// ===== START =====
startWA();