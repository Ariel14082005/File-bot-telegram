module.exports = {
    // =========================
    // TELEGRAM BOT
    // =========================
    TELEGRAM_TOKEN: "8639998236:AAFkic8u4QvcePQcb47s6LrKqEwPmKO2H80", // ganti dengan token asli

    // =========================
    // OWNER (ID Telegram)
    // =========================
    OWNER: [8741316348], // bisa lebih dari 1 ID

    // =========================
    // BROADCAST SETTINGS
    // =========================
    BROADCAST: {
        BATCH: 40,           // jumlah kontak sebelum istirahat
        DELAY: 90000,        // delay acak antar kirim pesan (ms)
        REST: 1800000        // durasi istirahat tiap batch (ms)
    }
};