module.exports = {
    TELEGRAM_TOKEN: "8639998236:AAFkic8u4QvcePQcb47s6LrKqEwPmKO2H80",
    OWNER: [admin],

    BROADCAST: {
        BATCH: 40,
        DELAY: 90000,
        REST: 1800000
    }
};