const delay =(ms) => new Promise(res =>setTimeout(res, ms));
function formatTime(ms) {
    let s = Math.floor(ms / 1000);
    let h = Math.floor(s / 3600);
    let m = Math.floor(s % 3600 / 60);
    return '%{h} jam ${m} menit';
}
