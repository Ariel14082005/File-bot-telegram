lconst fs = require("fs");
const path = require("path");
const { batchProcess, delay } = require("../utils/optimize");
const logger = require("../utils/logger");

const USERS_FILE = path.join(__dirname, "../storage/users.json");

let users = {};

function loadUsers() {
    try { users = JSON.parse(fs.readFileSync(USERS_FILE)); }
    catch { users = {}; }
}

function saveUsers() {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

function initUser(chatId) {
    if (!users[chatId]) {
        users[chatId] = { isRunning: false, waiting: false, message: "", sent: [], total: 0, sentCount: 0 };
    }
}

async function runBroadcast(bot, sock, chatId, contacts, user) {
    await batchProcess(contacts, 40, async (id) => {
        if (user.sent.includes(id)) return;

        try {
            await sock.sendMessage(id, { text: user.message });
            user.sent.push(id);
            user.sentCount++;
            logger.broadcast(`✅ ${id}`);
        } catch (err) {
            logger.error(`❌ ${id} - ${err.message}`);
        }

        if (user.sentCount % 40 === 0) {
            bot.sendMessage(chatId, `📊 Progress: ${user.sentCount}/${user.total}`);
            logger.info("😴 Istirahat 30 menit...");
        }
    }, 1800000); // 30 menit istirahat tiap batch
}

module.exports = async (bot, sock, msg, config) => {
    if (!msg || !msg.chat) return;

    const chatId = msg.chat.id;
    const text = msg.text;

    loadUsers();
    initUser(chatId);
    const user = users[chatId];

    if (!config.OWNER.includes(chatId)) return bot.sendMessage(chatId, "❌ Akses ditolak");
    if (user.isRunning && text !== "/status") return bot.sendMessage(chatId, "⚠️ Bot sedang berjalan...");

    if (text === "/start") return bot.sendMessage(chatId, "✅ Bot aktif");
    if (text === "/broadcast") { user.waiting = true; saveUsers(); return bot.sendMessage(chatId, "📩 Kirim pesan broadcast"); }
    if (text === "/cek") { const contacts = Object.keys(sock.store?.contacts || {}); return bot.sendMessage(chatId, `📊 Total kontak: ${contacts.length}`); }

    if (text === "/run") {
        if (!user.message) return bot.sendMessage(chatId, "❌ Pesan belum ada");
        const contacts = Object.keys(sock.store?.contacts || {});
        user.isRunning = true; user.sent = []; user.sentCount = 0; user.total = contacts.length;
        saveUsers();
        bot.sendMessage(chatId, `🚀 Mulai kirim ke ${contacts.length} kontak`);
        await runBroadcast(bot, sock, chatId, contacts, user);
        user.isRunning = false; saveUsers();
        return bot.sendMessage(chatId, "🎉 Broadcast selesai");
    }

    if (text === "/status") return bot.sendMessage(chatId, `📊 Progress:\n${user.sentCount}/${user.total}`);
    if (user.waiting && text) { user.message = text; user.waiting = false; saveUsers(); return bot.sendMessage(chatId, "✅ Pesan disimpan"); }
};