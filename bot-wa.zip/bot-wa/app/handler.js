const fs = require("fs");
const path = require("path");

// ===== STORAGE =====
const USERS_FILE = path.join(__dirname, "../storage/users.json");

// ===== LOAD USERS =====
let users = {};

function loadUsers() {
    try {
        users = JSON.parse(fs.readFileSync(USERS_FILE));
    } catch {
        users = {};
    }
}

function saveUsers() {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
}

// ===== INIT USER =====
function initUser(chatId) {
    if (!users[chatId]) {
        users[chatId] = {
            isRunning: false,
            waiting: false,
            message: "",
            sent: [],
            total: 0,
            sentCount: 0
        };
    }
}

// ===== HANDLER =====
module.exports = async (bot, sock, msg, config) => {
    const chatId = msg.chat.id;
    const text = msg.text;

    loadUsers();
    initUser(chatId);

    // ===== SECURITY (OWNER ONLY) =====
    if (!config.OWNER.includes(chatId)) {
        return bot.sendMessage(chatId, "❌ Akses ditolak");
    }

    const user = users[chatId];

    // ===== LOCK SYSTEM =====
    if (user.isRunning && text !== "/status") {
        return bot.sendMessage(chatId, "⚠️ Bot sedang berjalan...");
    }

    // ===== COMMAND =====
    if (text === "/start") {
        return bot.sendMessage(chatId, "✅ Bot aktif");
    }

    if (text === "/broadcast") {
        user.waiting = true;
        saveUsers();
        return bot.sendMessage(chatId, "📩 Kirim pesan untuk broadcast");
    }

    if (text === "/cek") {
        const contacts = Object.keys(sock.store?.contacts || {});
        return bot.sendMessage(chatId, `📊 Total kontak: ${contacts.length}`);
    }

    if (text === "/run") {
        if (!user.message) {
            return bot.sendMessage(chatId, "❌ Pesan belum ada");
        }

        user.isRunning = true;
        user.sent = [];
        user.sentCount = 0;

        saveUsers();

        const contacts = Object.keys(sock.store?.contacts || {});
        user.total = contacts.length;

        bot.sendMessage(chatId, `🚀 Mulai kirim ke ${contacts.length} kontak`);

        await runBroadcast(bot, sock, chatId, contacts, user);

        user.isRunning = false;
        saveUsers();

        return bot.sendMessage(chatId, "🎉 Broadcast selesai");
    }

    if (text === "/status") {
        return bot.sendMessage(
            chatId,
            `📊 Progress:\n${user.sentCount}/${user.total}`
        );
    }

    // ===== TERIMA PESAN =====
    if (user.waiting) {
        user.message = text;
        user.waiting = false;
        saveUsers();

        return bot.sendMessage(chatId, "✅ Pesan disimpan");
    }
};

// ===== DELAY =====
const delay = (ms) => new Promise((res) => setTimeout(res, ms));

function randomDelay() {
    return Math.floor(Math.random() * (40000 - 10000)) + 10000;
}

// ===== BROADCAST =====
async function runBroadcast(bot, sock, chatId, contacts, user) {
    for (let i = 0; i < contacts.length; i++) {
        const id = contacts[i];

        if (user.sent.includes(id)) continue;

        try {
            await sock.presenceSubscribe(id);
            await sock.sendPresenceUpdate("composing", id);

            await delay(3000);

            await sock.sendMessage(id, {
                text: user.message
            });

            await sock.sendPresenceUpdate("paused", id);

            user.sent.push(id);
            user.sentCount++;

            console.log("✅", id);

        } catch (err) {
            console.log("❌", id);
        }

        // ===== AUTO STATUS =====
        if (user.sentCount % 40 === 0) {
            bot.sendMessage(
                chatId,
                `📊 Progress: ${user.sentCount}/${user.total}`
            );

            console.log("😴 Istirahat 30 menit...");
            await delay(1800000);
        }

        await delay(randomDelay());
    }
}