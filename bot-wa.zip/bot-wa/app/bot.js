const TelegramBot = require("node-telegram-bot-api");
const makeWASocket = require("@whiskeysockets/baileys").default;
const { useMultiFileAuthState } = require("@whiskeysockets/baileys");
const path = require("path");

const config = require("../config/config");
const handler = require("./handler");

const BASE = path.join(__dirname, "..");
const SESSION_DIR = path.join(BASE, "storage/session");
const SENT_DIR = path.join(BASE, "storage/sent");

async function start() {
    try {
        console.log("🔌 Menghubungkan ke WhatsApp...");

        const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

        const sock = makeWASocket({
            auth: state,
            printQRInTerminal: true
        });

        sock.ev.on("creds.update", saveCreds);

        // ✅ STATUS KONEKSI WA
        sock.ev.on("connection.update", (update) => {
            const { connection, lastDisconnect } = update;

            if (connection === "close") {
                console.log("❌ WA terputus, mencoba reconnect...");

                // reconnect otomatis
                start();
            } 
            
            if (connection === "open") {
                console.log("✅ WhatsApp tersambung!");
            }
        });

        // ✅ TELEGRAM BOT
        let bot = null;

        if (config.TELEGRAM_TOKEN) {
            bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });
            console.log("🤖 Telegram bot aktif");
        } else {
            console.log("⚠️ TELEGRAM_TOKEN kosong, Telegram dimatikan");
        }

        // ✅ HANDLER
        console.log("⚙️ Handler dijalankan...");
        handler(bot, sock, SENT_DIR);

    } catch (err) {
        console.log("💥 Error di start():", err);

        // retry kalau crash
        setTimeout(start, 5000);
    }
}

// ✅ export ke index.js
module.exports = start;