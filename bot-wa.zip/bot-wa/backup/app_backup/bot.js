const TelegramBot = require("node-telegram-bot-api");
const makeWASocket = require("@whiskeysockets/baileys").default;
const { useMultiFileAuthState } = require("@whiskeysockets/baileys");
const path = require("path");

const config = require("../config/config");

const handler = require("./handler");

const BASE = path.join(__dirname, "..");

const SESSION_DIR = path.join(BASE, "storage/session");
const SENT_DIR = path.join(BASE, "storage/sent");

async function start() {

    const { state, saveCreds } = await useMultiFileAuthState(SESSION_DIR);

    const sock = makeWASocket({
        auth: state,
        printQRInTerminal: true
    });

    sock.ev.on("creds.update", saveCreds);

    const bot = new TelegramBot(config.TELEGRAM_TOKEN, { polling: true });

    handler(bot, sock, SENT_DIR);
}

start();