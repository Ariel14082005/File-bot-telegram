const fs = require("fs")
const path = require("path")
const { delay } = require("./function");

let user = {};

function iniUser(chatid) {
    if ( !users[chatid]) {
        users[chatid] = {
            isRuning: false,
            message: "",
            sent: [],
            total: 0,
            senCount: 0
        };
    }
}

function loadSent(chatId, SENT_DIR) {
    const filePath = path.join(SENT_DIR, `sent_${chatId}.json`);
    if (fs.existsSync(filePath)) {
        return JSON.parse(fs.readFileSync(filePath));
    }
    return [];
}
function saveSent(chatId, SENT_DIR, data) {
    const filePath = path.join(SENT_DIR, `sent_${chatId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = (bot, sock, SENT_DIR) => {

    bot.onText(/\/start/, (msg) => {
        bot.sendMessage(msg.chat.id, "✅ Bot aktif\n\n/broadcast\n/cek\n/run\n/status");
    });

    bot.onText(/\/broadcast/, (msg) => {
        const chatId = msg.chat.id;
        initUser(chatId);

        if (users[chatId].isRunning) {
            return bot.sendMessage(chatId, "⛔ Sedang berjalan");
        }

        users[chatId].waiting = true;
        bot.sendMessage(chatId, "📩 Kirim pesan broadcast");
    });

    bot.on("message", (msg) => {
        const chatId = msg.chat.id;
        if (!users[chatId]?.waiting) return;
        if (msg.text.startsWith("/")) return;

        users[chatId].waiting = false;
        users[chatId].message = msg.text;

        bot.sendMessage(chatId, "✅ Pesan disimpan\nKetik /run");
    });

    bot.onText(/\/cek/, (msg) => {
        const chatId = msg.chat.id;
        initUser(chatId);

        const contacts = Object.keys(sock.store?.contacts || {});
        const valid = contacts.filter(x => x.endsWith("@s.whatsapp.net"));

        bot.sendMessage(chatId, `📦 Total kontak: ${valid.length}`);
    });

    bot.onText(/\/status/, (msg) => {
        const chatId = msg.chat.id;
        initUser(chatId);

        let u = users[chatId];

        bot.sendMessage(chatId,
`📊 STATUS

✅ ${u.sentCount}
📦 ${u.total}
⏳ ${u.total - u.sentCount}`);
    });

    bot.onText(/\/run/, async (msg) => {
        const chatId = msg.chat.id;
        initUser(chatId);

        let u = users[chatId];

        if (u.isRunning) return bot.sendMessage(chatId, "⛔ Sudah berjalan");
        if (!u.message) return bot.sendMessage(chatId, "❌ /broadcast dulu");

        u.isRunning = true;

        const BATCH = 40;
        const DELAY = 90000;
        const REST = 1800000;

        const contacts = Object.keys(sock.store?.contacts || {});
        const valid = contacts.filter(x => x.endsWith("@s.whatsapp.net"));

        u.total = valid.length;
        u.sent = loadSent(chatId, SENT_DIR);

        for (let id of valid) {
            if (u.sent.includes(id)) continue;

            try {
                await sock.sendMessage(id, { text: u.message });

                u.sent.push(id);
                u.sentCount++;

                saveSent(chatId, SENT_DIR, u.sent);

                if (u.sentCount % BATCH === 0) {
                    bot.sendMessage(chatId, `📊 ${u.sentCount}/${u.total}\nIstirahat 30 menit`);
                    await delay(REST);
                }

                await delay(DELAY);

            } catch (err) {
                console.log(err);
            }
        }

        u.isRunning = false;
        bot.sendMessage(chatId, "🎉 Selesai");
    });
};